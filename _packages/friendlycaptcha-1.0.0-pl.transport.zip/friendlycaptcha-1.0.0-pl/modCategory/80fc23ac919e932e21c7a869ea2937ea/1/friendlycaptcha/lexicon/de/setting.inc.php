<?php
/**
 * Setting Lexicon Entries
 *
 * @package friendlyCaptcha
 * @subpackage lexicon
 */
$_lang['setting_friendlycaptcha.sitekey'] = 'Site Key';
$_lang['setting_friendlycaptcha.secret'] = 'Secret';
