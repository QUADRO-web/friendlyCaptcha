<?php
/**
 * German Lexicon Entries
 *
 * @package friendlyCaptcha
 * @subpackage lexicon
 *
 */

$_lang['friendlycaptcha.error'] = 'Error verifying Captcha, please try again.';
