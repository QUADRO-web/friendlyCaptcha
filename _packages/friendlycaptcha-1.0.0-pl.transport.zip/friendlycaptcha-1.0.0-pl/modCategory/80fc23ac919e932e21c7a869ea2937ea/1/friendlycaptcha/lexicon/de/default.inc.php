<?php
/**
 * German Lexicon Entries
 *
 * @package friendlyCaptcha
 * @subpackage lexicon
 *
 */

$_lang['friendlycaptcha.error'] = 'Fehler beim Verifizieren des Captchas, bitte versuchen Sie es erneut.';
