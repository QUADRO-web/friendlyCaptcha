
friendlyCaptcha

Author: Jan Dähne <https://www.quadro.digital>
Copyright 2024

Official Documentation: https://www.quadro.digital/modx-extras/friendlyCaptcha/

Bugs and Feature Requests: https://github.com/QUADRO-web/friendlyCaptcha

Questions: http://forums.modx.com
